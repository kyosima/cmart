<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PolicyController extends Controller
{
    //
    public function gt(){
        return view ('chinhsach.gt');
    }
    public function csdd(){
        return view ('chinhsach.csdd');
    }
    public function hddh(){
        return view ('chinhsach.hddh');
    }
    public function cstt(){
        return view ('chinhsach.cstt');
    }
    public function csgn(){
        return view ('chinhsach.csgn');
    }
    public function csdt(){
        return view ('chinhsach.csdt');
    }
    public function csbh(){
        return view ('chinhsach.csbh');
    }
    public function qddk(){
        return view ('chinhsach.qddk');
    }
    public function khdb(){
        return view ('chinhsach.qlv');
    }
    public function dt(){
        return view ('chinhsach.dt');
    }





}
