
$(document).ready(function() {
    $('.select2').select2({
        placeholder: 'Vui lòng chọn',
        allowClear: true,
        theme: "classic",
        width: '100%'
    });
});