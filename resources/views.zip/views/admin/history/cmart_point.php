<div class="row pb-3">
    <div class="col-12">
        <a class="btn btn-primary text-white" style="width: 100%">
            Tổng điểm C hiện tại tài khoản Cmart: 10
        </a>
    </div>
</div>