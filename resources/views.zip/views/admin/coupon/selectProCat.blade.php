<div class="form-group d-flex mb-2 div-select-procat">
    <label class="col-md-3 control-label">Danh mục sản phẩm ưu đãi<span class="required"
            aria-required="true">(*)</span></label>
    <div class="col-md-9">
        <select name="procat_promo[]" id="select-procat" class="form-control" multiple required>
        </select>
    </div>
</div>