<div class="form-group d-flex mb-2 div-select-product">
    <label class="col-md-3 control-label">Sản phẩm ưu đãi<span class="required"
            aria-required="true">(*)</span></label>
    <div class="col-md-9">
        <select name="product_promo[]" id="select-product" class="form-control" multiple required>
        </select>
    </div>
</div>