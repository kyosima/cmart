<div class="header bg-white shadow-sm header_mobile">
    <div class="text">@yield('title')</div>
    <div class="icon_menu-mobile">
        <i class="fa fa-bars" data-bs-toggle="collapse" href="#menu-main" role="button" aria-expanded="false" aria-controls="menu-main"></i>
    </div>
</div>
  <ul class="sub-menu collapse sidebar-mobile list-group list-group-flush" id="menu-main">
      <li class="list-group-item p-0 list-group-item-action">
          <a href="#" class="list-group-item-link p-3"><i class="fa fa-bar-chart-o"></i> Dashboard</a>
      </li>
      <li class="list-group-item p-0 list-group-item-action">
          <a href="#" class="list-group-item-link p-3"><i class="fa fa-bar-chart-o"></i> Quản lý sản phẩm</a>
      </li>
      <li class="list-group-item p-0 list-group-item-action">
          <a href="#" class="list-group-item-link p-3"><i class="fa fa-bar-chart-o"></i> Đon hàng</a>
      </li>
      <li class="list-group-item p-0 list-group-item-action">
          <a href="#" class="list-group-item-link p-3"><i class="fa fa-bar-chart-o"></i> Tồn kho</a>
      </li>
      <li class="list-group-item p-0 list-group-item-action">
          <a href="#" class="list-group-item-link p-3"><i class="fa fa-bar-chart-o"></i> Dữ liệu Master</a>
      </li>
      <li class="list-group-item p-0 list-group-item-action">
          <a href="setting.html" class="list-group-item-link p-3"><i class="fa fa-bar-chart-o"></i> Setting</a>
      </li>
  </ul>
</div>