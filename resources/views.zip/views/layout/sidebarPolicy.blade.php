<div class="list-group ">
    <a href="{{route('policy.gt')}}" class="content-hover-border list-group-item list-group-item-action "><i
            class="fas fa-info-circle"></i> Giới thiệu C-Mart</a>
    <a href="#" class="active-cs content-hover-border list-group-item list-group-item-action "><i
            class="fas fa-info-circle"></i> Chăm sóc khách hàng</a>
    <a href="{{ route('policy.csgn') }}"
        class="content-hover  list-group-item list-group-item-action  border-bottom-0 border-right-0 border-left-0">Chính sách giao nhận</a>
    <a href="{{ route('policy.cstt') }}"
        class="content-hover content-list list-group-item list-group-item-action border-0 ">Chính sách thanh toán</a>
    <a href="{{ route('policy.hddh') }}"
        class="content-hover content-list list-group-item list-group-item-action border-0">Hướng dẫn đặt hàng</a>
    <a href="{{ route('policy.csdt') }}"
        class="active-csv content-hover content-list list-group-item list-group-item-action border-0">Chính sách đổi trả</a>
    <a href="{{ route('policy.csbh') }}"
        class="content-hover content-list list-group-item list-group-item-action border-0">Chính
        sách bảo hành </a>
    <a href="{{ route('policy.qddk') }}"
    class="content-hover content-list list-group-item list-group-item-action border-0">Quy định bán hàng </a>
    <a href="{{ route('policy.khdb') }}"
        class="content-hover content-list list-group-item list-group-item-action border-0">Khách hàng đặc biệt </a>
    <a href="{{ route('policy.dt') }}"
        class="content-hover content-list list-group-item list-group-item-action border-0">Đối tác </a>
  
</div>