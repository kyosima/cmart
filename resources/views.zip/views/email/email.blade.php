<!DOCTYPE html>
<html>
<head>
 <title>CÔNG TY TNHH THƯƠNG MẠI DỊCH VỤ C-MART</title>
</head>
<body>
 
 <h3>CÔNG TY TNHH THƯƠNG MẠI DỊCH VỤ C-MART</h3>
 <p><span>Mã đơn hàng: </span><b>{{$order->order_code}}</b></p>
 <p>Xin gửi đến quý khách hóa đơn C-Bill của đơn hàng</p>
 <p>Chúc quý khách một ngày tốt lành</p>
 <p>Trân trọng</p>
</body>
</html>