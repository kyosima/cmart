<?php

namespace Devt\Payme\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SettingPaymentPayme extends Model
{
    use HasFactory;
    protected $table = 'setting_payment_payme';

    protected $guarded = [];

}
